package kr.ac.cnu.computer.week12;

import android.database.sqlite.SQLiteDatabase;
import android.icu.util.Output;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import static kr.ac.cnu.computer.week12.MessageType.LEFT_CONTENTS;

public class MainActivity extends AppCompatActivity {
    private DBHelper dbHelper;
    private Handler mHandler;
    int portNumber = 8888;
    Socket sock;
    EditText editText;
    String message = "" ; // 입력한 메세지를 담을 변수 message
    List<Message> list;
    RecyclerView recyclerview;
    MessageAdapter adapter;
    String read;
    char[] msgfromserver = new char[9999];


    /*
        문제에 맞게 onCreate 메소드를 정의하시오.
    */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mHandler = new Handler();

        dbHelper = new DBHelper(this, 1);
        list = dbHelper.selectAll(); // 싹다 가져오자. 실행할 때는 싹다 가져와서 보여줘야 함
        recyclerview = findViewById(R.id.recyclerView);
        adapter = new MessageAdapter(list);
        recyclerview.setAdapter(adapter);





        // 소켓연결스레드
        class socketRunnable implements Runnable{
            @Override
            public void run(){
                try{
                    sock = new Socket("chopper.kim",portNumber);
                    if(sock.isConnected()){
                        Log.d("연결","됐음");
                    }
                    InputStream input = sock.getInputStream();
                    Log.d("연결1","됐음1");
                    BufferedReader bfr = new BufferedReader(new InputStreamReader(sock.getInputStream()));

                    while(true){
                        read = bfr.readLine();

                        long id = dbHelper.insert(read,LEFT_CONTENTS);
                        list.add(dbHelper.selectOne(id));
                        ////////
                        mHandler.post(new updating());



                    }

                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        }
        socketRunnable sr = new socketRunnable();
        Thread sr1 = new Thread(sr);
        sr1.start();
        //소켓연결스레드끝



        // 여기부터는 버튼 누르는 부분임
        Button send = findViewById(R.id.sendButton);
        send.setEnabled(false);

        editText = findViewById(R.id.contentsEdit);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                message = editText.getText().toString();
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (editable.toString().length() > 0) {
                    send.setEnabled(true);
                } else {
                    send.setEnabled(false);
                }
            }
        });
        // 여기까지 버튼 누르는 부분임


        recyclerview.smoothScrollToPosition(list.size());

    } // onCreate의 끝

    class updating implements Runnable{
        public void run(){
            adapter.notifyDataSetChanged();
            recyclerview.smoothScrollToPosition(list.size());
        }
    }


    /*
        전송 버튼을 누를 때 동작 되는 메소드
        이 메소드 내용 작성
    */

    public void sendAction(View view) {
        MessageType type = MessageType.of(2);
        String data = editText.getText().toString();
        long id = dbHelper.insert(data,type); // 어차피 보내는 타입밖에 없음 db에 메세지 등록
        // db에 저장한 id값을 담을 변수인 id
        list.add(dbHelper.selectOne(id)); // db에서 꺼내오고 리스트에 담아주자.

        adapter.notifyDataSetChanged();
        recyclerview.smoothScrollToPosition(list.size());

        //소켓스레드시작
        class sockRunnable implements Runnable{
            @Override
            public void run(){
                try{
                    sock = new Socket("chopper.kim",portNumber);
                    if(sock.isConnected()){
                        Log.d("연결1","됐음1");
                    }
                    BufferedWriter bfw = new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()));
                    bfw.write(data);
                    bfw.flush();

                }catch(Exception e){
                    e.printStackTrace();
                }

            }
        }

        sockRunnable sr = new sockRunnable();
        Thread sr1 = new Thread(sr);
        sr1.start();
        //소켓스레드끝


        editText.setText(null); // 메세지 지우기
    }
}
